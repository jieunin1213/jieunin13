# coding: utf-8

# flask
from flask import Flask, render_template

#request
from flask import request

#CORS
from flask_cors import CORS 

#requests
import requests
import json
import logging
import datetime

###############################################################

# 센서 값 정의하기

import time
from pyfingerprint.pyfingerprint import PyFingerprint
import RPi.GPIO as gpio
import logging
#############################################################
# 지문인식 센서 감지 log 남기기
date = str(datetime.date.today())

logger = logging.getLogger('fingerprintlog')
hand = logging.FileHandler(date + '.log')



#                              생성시간,   로그레벨 ,       프로세스ID,   메시지
formatter = logging.Formatter('%(asctime)s %(levelname)s %(process)d %(message)s')

# 파일핸들러에 문자열 포메터를 등록
hand.setFormatter(formatter)

logger.addHandler(hand)

logger.setLevel(logging.INFO)

logger.info('match')
logger.warning('no match')


#############################웹에서 로그파일 보기###########################

# app = Flask(__name__)
# 
# #Cross origins 이슈 해결
# CORS(app)
# 
# @app.route('/logs/v1/<date>')
# def read_log(date):
#     
#     date = str(datetime.date.today())
# 
#     contents = ''
# 
#     with open(date+'.log', 'r') as file:
#         contents = '<h1>'+date+'</h1>'
#         line = None    # 변수 line을 None으로 초기화
#         while line != '':
#             line = file.readline()
#             contents += line + '<br>'
#     return contents
# 
# if __name__ == '__main__':
#     app.run(host='192.168.0.63', port=5000, debug=True)
# 

#############################################################3
RS =18 # RS ~ D7 LED 판 센서
EN =23
D4 =24
D5 =25
D6 =8
D7 =7

enrol=5 # 새로운 지문을 등록하는 버튼

led=26 # 미니 전구

HIGH=1
LOW=0

##############################################################

# GPIO핀 초기화 하기(초기 값으로 설정)

gpio.setwarnings(False)
gpio.setmode(gpio.BCM)
gpio.setup(RS, gpio.OUT)
gpio.setup(EN, gpio.OUT)
gpio.setup(D4, gpio.OUT)
gpio.setup(D5, gpio.OUT)
gpio.setup(D6, gpio.OUT)
gpio.setup(D7, gpio.OUT)
gpio.setup(enrol, gpio.IN, pull_up_down=gpio.PUD_UP)
gpio.setup(led, gpio.OUT)

#############################################################

# 지문인식센서 초기화 하기(초기 값으로 설정)

try:
    f = PyFingerprint('/dev/ttyAMA0', 57600, 0xFFFFFFFF, 0x00000000)
    
    if ( f.verifyPassword() == False ):
        raise ValueError('The given fingerprint sensor password is wrong!')
    
except Exception as e:
    print('Exception message: ' + str(e))
    exit(1)
################################################################

# LED 판 센서 초기화 하기(초기 값으로 설정)

def begin():
  lcdcmd(0x33) 
  lcdcmd(0x32) 
  lcdcmd(0x06)
  lcdcmd(0x0C) 
  lcdcmd(0x28) 
  lcdcmd(0x01) 
  time.sleep(0.0005)
 
def lcdcmd(ch): 
  gpio.output(RS, 0)
  gpio.output(D4, 0)
  gpio.output(D5, 0)
  gpio.output(D6, 0)
  gpio.output(D7, 0)
  if ch&0x10==0x10:
    gpio.output(D4, 1)
  if ch&0x20==0x20:
    gpio.output(D5, 1)
  if ch&0x40==0x40:
    gpio.output(D6, 1)
  if ch&0x80==0x80:
    gpio.output(D7, 1)
  gpio.output(EN, 1)
  time.sleep(0.005)
  gpio.output(EN, 0)
  # Low bits
  gpio.output(D4, 0)
  gpio.output(D5, 0)
  gpio.output(D6, 0)
  gpio.output(D7, 0)
  if ch&0x01==0x01:
    gpio.output(D4, 1)
  if ch&0x02==0x02:
    gpio.output(D5, 1)
  if ch&0x04==0x04:
    gpio.output(D6, 1)
  if ch&0x08==0x08:
    gpio.output(D7, 1)
  gpio.output(EN, 1)
  time.sleep(0.005)
  gpio.output(EN, 0)
  
def lcdwrite(ch): 
  gpio.output(RS, 1)
  gpio.output(D4, 0)
  gpio.output(D5, 0)
  gpio.output(D6, 0)
  gpio.output(D7, 0)
  if ch&0x10==0x10:
    gpio.output(D4, 1)
  if ch&0x20==0x20:
    gpio.output(D5, 1)
  if ch&0x40==0x40:
    gpio.output(D6, 1)
  if ch&0x80==0x80:
    gpio.output(D7, 1)
  gpio.output(EN, 1)
  time.sleep(0.005)
  gpio.output(EN, 0)
  # Low bits
  gpio.output(D4, 0)
  gpio.output(D5, 0)
  gpio.output(D6, 0)
  gpio.output(D7, 0)
  if ch&0x01==0x01:
    gpio.output(D4, 1)
  if ch&0x02==0x02:
    gpio.output(D5, 1)
  if ch&0x04==0x04:
    gpio.output(D6, 1)
  if ch&0x08==0x08:
    gpio.output(D7, 1)
  gpio.output(EN, 1)
  time.sleep(0.005)
  gpio.output(EN, 0)
def lcdclear():
  lcdcmd(0x01)
 
def lcdprint(Str):
  l=0;
  l=len(Str)
  for i in range(l):
    lcdwrite(ord(Str[i]))
    
def setCursor(x,y):
    if y == 0:
        n=128+x
    elif y == 1:
        n=192+x
    lcdcmd(n)

######################################################

# 새로운 지문을 등록하는 함수

def enrollFinger(): 
    lcdcmd(1)
    lcdprint("  new finger  ")
    lcdcmd(192)
    lcdprint("  enroll system  ")
    time.sleep(2)
    print('wait please...')
    lcdcmd(1)
    lcdprint("put new finger.")
    
    while ( f.readImage() == False ): # f.readImage : 센서가 지문을 읽는 것 ! # 지문이 인식되기를 기다림
        pass
    f.convertImage(0x01)
    result = f.searchTemplate()
    positionNumber = result[0] 

    if ( positionNumber >= 0 ):
        print('this finger exists aleady : #' + str(positionNumber))
        lcdcmd(1)
        lcdprint("  this finger  ")
        lcdcmd(192)
        lcdprint(" exists aleady  ")
        time.sleep(2)
        return

    # 새로운 지문이라면, 위 if문 에 안걸린다! 바로 아래 코드 실행.


    print('remove your finger...') # 지문을 등록시에, 두번 인식을 해서 지문 등록 정확성을 up시킨다.
    lcdcmd(1)
    lcdprint(" remove finger ")
    time.sleep(2)
    print(' wait please... ')
    lcdcmd(1)
    lcdprint("  put your   ")
    lcdcmd(192)
    lcdprint("   finger again   ")
    
    while ( f.readImage() == False ): # 두번째 인식. # 지문이 인식되기를 기다림.
        pass
    f.convertImage(0x02)
    
    if ( f.compareCharacteristics() == 0 ):
        print (" this finger no match ")
        lcdcmd(1)
        lcdprint("  this finger  ")
        lcdcmd(192)
        lcdprint(" no match  ")
        time.sleep(2)
        return
    
    # 두번째 인식 때, 지문이 일치했다면 위 if문 에 안걸린다! 바로 아래 코드 실행.
    
    f.createTemplate() # 새로운 지문이 완벽히 등록 되었을 때
    positionNumber = f.storeTemplate()
    print('new finger enrolls sucessfully')
    lcdcmd(1)
    lcdprint(" new finger enroll : " + str(positionNumber))
    print(' new finger enroll : #' + str(positionNumber))
    time.sleep(2)

############################################################## 

# 일치하는 지문을 찾는 함수
def searchFinger():
    try:
        print('wait please...')
        while( f.readImage() == False ):
            #pass
            time.sleep(.5)
            return
        f.convertImage(0x01)
        result = f.searchTemplate()
        positionNumber = result[0]
        accuracyScore = result[1]
        
        if positionNumber == -1 :
            print(' Fail! match finger is not here')
            lcdcmd(1)
            lcdprint(" Fail! ")
            logger.warning('no match')   
            time.sleep(2)
            return
        
        else:
            print(' Success! Sensor finds match finger : #' + str(positionNumber))
            lcdcmd(1)
            lcdprint(" Success! : " + str(positionNumber)) 
            logger.info('match')
            time.sleep(2)
             # 지문이 일치하면, 문이 열리도록 아래에 코드 추가할 예정.
    except Exception as e:
        print('sensor function is interrupted')
        print('exception message: ' + str(e))
        exit(1)
    
#####################################################        

# 지문인식센서를 시작할 때

begin() 
lcdcmd(0x01)
lcdprint(" finger print system ")
time.sleep(3)
lcdcmd(0xc0)
lcdprint(" system starts ")
time.sleep(3)
flag=0
lcdclear()
while 1:
    gpio.output(led, HIGH) # 지문등록시에만 미니전구 꺼지고, 다른 때엔 항상 켜지게 할 것
    lcdcmd(1)
    lcdprint("  put your  ") # 계속 반복
    lcdcmd(192)
    lcdprint("  finger  ")
   
    if gpio.input(enrol) == 0: #새로운 지문을 등록하려면 enrol 버튼을 눌러야 한다.
        gpio.output(led, LOW)
        enrollFinger()

    else:
        searchFinger() # 새로운 지문 등록시 외에..계속 실행되는 함수
