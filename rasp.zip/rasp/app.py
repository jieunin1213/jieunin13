
from flask import Flask

import RPi.GPIO as GPIO
# 핀번호 할당 설정
GPIO.setmode(GPIO.BOARD)
LIGHT_1 = 16 
GPIO.setup(LIGHT_1, GPIO.OUT, initial=GPIO.LOW) 


app = Flask(__name__)

@app.route('/')
def light_on():
    GPIO.output(LIGHT_1, GPIO.HIGH)
    return 'light sensor page'

@app.route('/light_on')
def light_on():
    GPIO.output(LIGHT_1, GPIO.HIGH)
    return ' light on'

@app.route('/light_off')
def light_off():
    GPIO.output(LIGHT_1, GPIO.LOW)

print(__name__)
if __name__ == '__main__':
    app.run(host='192.168.0.63', port=5000, debug=False)