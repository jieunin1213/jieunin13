# coding: utf-8

# flask
from flask import Flask, render_template

#request
from flask import request

#CORS
from flask_cors import CORS

#requests
import requests
import json
import logging
import datetime

date = str(datetime.date.today())
print(date)

logger = logging.getLogger('fingerprintlog')
hand = logging.FileHandler(date + '.log')



#                              생성시간,   로그레벨 ,       프로세스ID,   메시지
formatter = logging.Formatter('%(asctime)s %(levelname)s %(process)d %(message)s')

# 파일핸들러에 문자열 포메터를 등록
hand.setFormatter(formatter)

logger.addHandler(hand)

logger.setLevel(logging.INFO)

logger.info('지문 일치')
logger.warning('지문 비일치')


##################################밑에는 웹에서 처리###########################

app = Flask(__name__)

#Cross origins 이슈 해결
CORS(app)

@app.route('/logs/v1/<date>')
def read_log(date):
    
    date = str(datetime.date.today())

    contents = ''

    with open(date+'.log', 'r') as file:
        contents = '<h1>'+date+'</h1>'
        line = None    # 변수 line을 None으로 초기화
        while line != '':
            line = file.readline()
            contents += line + '<br>'
    return contents

if __name__ == '__main__':
    app.run(host='192.168.0.63', port=5000, debug=True)
