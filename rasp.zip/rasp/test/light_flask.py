# coding: utf-8

from flask import Flask
from flask_cors import CORS
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)
LIGHT = 16
GPIO.setup(LIGHT, GPIO.OUT, initial=GPIO.LOW)

app = Flask(__name__)
CORS(app)

@app.route('/')
def index():
    GPIO.output(LIGHT, GPIO.LOW)

    led =  request.args.get('led', 'g')
    p_val = request.args.get('p_val', '0')

    return '조명 센서 제어 페이지입니다'

@app.route('/light_on')
def light_on_2():
    GPIO.output(LIGHT, GPIO.HIGH)
    return 'light on'

@app.route('/light_off')
def light_off():
    GPIO.output(LIGHT, GPIO.LOW)
    return 'light off'

if __name__ == '__main__':
    app.run(host='192.168.0.63', port=5000, debug=False)
