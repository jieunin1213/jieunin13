import Adafruit_DHT
import time
import RPi.GPIO as GPIO
import time

GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)
A = 17 #모터 A핀
B = 27 #모터 B핀
GPIO.setup(A,GPIO.OUT) #A,B GPIO setup설정
GPIO.setup(B,GPIO.OUT)

DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 19


    #humidity, temperature = Adafruit_DHT.read(DHT_SENSOR, DHT_PIN)
    #if humidity is not None and temperature is not None:
        #print("Temp={0:0.1f}C Humidity={1:0.1f}%".format(temperature, humidity))
        
try:
    while True:
        print("선풍기를 가동합니다.")
        print("Right")
        GPIO.output(A,GPIO.HIGH)  #오른쪽 회전
        GPIO.output(B,GPIO.LOW)
        time.sleep(5) #5초 유지
        print("Left")
        GPIO.output(A,GPIO.LOW) #왼쪽 회전
        GPIO.output(B,GPIO.HIGH)
        time.sleep(5) #5초 유지
        GPIO.output(A,GPIO.LOW) #정지
        GPIO.output(B,GPIO.LOW)  
        time.sleep(1)   #1초 유지
        
except KeyboardInterrupt:
    GPIO.output(A,GPIO.LOW) #정지
    GPIO.output(B,GPIO.LOW)
    GPIO.cleanup()

                    
        #else:
            #print("선풍기를 멈춥니다.")
            #GPIO.output(A,GPIO.LOW)
            #GPIO.output(B,GPIO.LOW)
            #time.sleep(5) #5초 유지
            #print("온도를 재측정합니다.")

GPIO.output(A,GPIO.LOW) #정지
GPIO.output(B,GPIO.LOW)  
GPIO.cleanup()