from flask import Flask
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BOARD)
LIGHT = 16  # 초록색 LED

GPIO.setup(LIGHT, GPIO.OUT, initial=GPIO.LOW)

app = Flask(__name__)

@app.route('/')
def light_on():
    GPIO.output(LIGHT, GPIO.HIGH)
    return 'light sensor page'

@app.route('/light_on')
def light_on():
    GPIO.output(LIGHT, GPIO.HIGH)
    return ' light on'

@app.route('/light_off')
def light_off():
    GPIO.output(LIGHT, GPIO.LOW)

if __name__ == '__main__':
    app.run(host='192.168.0.63', port=5000, debug=False)
