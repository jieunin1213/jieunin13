import Adafruit_DHT
import time
import RPi.GPIO as GPIO


GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

A = 17 #모터 A핀
B = 27 #모터 B핀

start_btn = 6 #선풍기 start 버튼
stop_btn = 5

#A,B GPIO setup설정
GPIO.setup(A,GPIO.OUT,initial=GPIO.LOW) 
GPIO.setup(B,GPIO.OUT,initial=GPIO.LOW)
GPIO.setup(start_btn, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(stop_btn, GPIO.IN, pull_up_down=GPIO.PUD_UP)

#온습도센서
DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 19


#회전의 강도
def strength(state):
    if state == 'high_wind':
        print("선풍기를 강풍으로 가동합니다.")
        p1=GPIO.PWM(A,30)
        p2=GPIO.PWM(B,30)
        p1.start(50)
        time.sleep(5)

        return 'high_wind'

    elif state == 'low_wind':
        print("선풍기를 약풍으로 가동합니다.")
        p1=GPIO.PWM(A,10)
        p2=GPIO.PWM(B,10)
        p1.start(30)
        time.sleep(5)


        return 'low_wind'


def dht11():
    while True:
        humidity, temperature = Adafruit_DHT.read(DHT_SENSOR, DHT_PIN)
        if humidity is not None and temperature is not None:
            print("Temp={0:0.1f}C Humidity={1:0.1f}%".format(temperature, humidity))
            
            if(temperature >= 25.0):
                strength('high_wind')
                print("온도를 재측정합니다.")
                
            else:
                strength('low_wind')
                print("온도를 재측정합니다.")
        else:
            print("Sensor failure. Check again. ");
            
        time.sleep(1);


GPIO.add_event_detect(start_btn, GPIO.FALLING, callback=dht11)

try:
    
    GPIO.wait_for_edge(stop_btn, GPIO.RISING)

except KeyboardInterrupt:
    GPIO.cleanup()
            
    
    
    #if GPIO.input(stop_btn) == 0:
       # GPIO.output(A,GPIO.LOW)
       # GPIO.output(B,GPIO.LOW)
        

#GPIO.output(A,GPIO.LOW) #정지
#GPIO.output(B,GPIO.LOW)  
GPIO.cleanup()
