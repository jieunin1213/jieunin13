import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)


SRV=18

GPIO.setup(SRV, GPIO.OUT)

freq = 100.0

deg_min = 0.0
deg_max = 360.0

dc_min = 5.0
dc_max = 22.0

def convert_dc(deg):
    return ((deg-deg_min)*(dc_max-dc_min)/(deg_max-deg_min)+dc_min)


p = GPIO.PWM(SRV, freq)

p.start(0)

try:
    while True:
        dc=convert_dc(float(360))
        p.ChangeDutyCycle(dc)
        time.sleep(2)
        dc=convert_dc(float(0))
        p.ChangeDutyCycle(dc)
        time.sleep(2)

except KeybordInterrupt:
     p.stop()
    
GPIO.cleanup()



