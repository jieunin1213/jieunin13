# coding: utf-8   => 한글차이 때문에 사용한다.

# GPIO 모듈
import RPi.GPIO as GPIO

import time

# GPIO 핀번호 할당 
GPIO.setmode(GPIO.BOARD)

# pin 번호 channel
LED = 11

# 밝기 목록 (밝기의 세기가 0.0 ~ 100%까지)
dc = [0,1,2,3,4,5,6,7,8,9,10,12,13,15,20,30,50,70,100]

# 핀 설정
GPIO.setup(LED, GPIO.OUT, initial=GPIO.LOW)

# PWM 객체 생성 : 11번 핀, 주파수 - 100Hz
p = GPIO.PWM(LED, 100)

import tkinter as tk

# window Obj
window = tk.Tk()
# window size
window.geometry('300x300')

# 변수 설정
led_value = tk.DoubleVar()
led_value.set(0) #value값을 정한다.

# duty 값을 변경 함수
def change_duty(dc):   # 밝기를 바꾸어주는 함수
    p.ChangeDutyCycle(led_value.get()) #value값을 받는다.

# 슬라이드 객체 생성
# 레이블(LED 밝기 조정), 숫자 범위(0~100)
slide = tk.Scale(window,
 label='LED 밝기 조정',
 orient='h', 
 from_=0,
 to=100,
 variable=led_value,
 command=change_duty ) #orient 수평방향..   

slide.pack()
window.mainloop()

#########################################

# PWM 신호 출력
p.start(0) 

while 1 : # 1은 무한반복

    for value in dc: # dc안에서 반복이 된다.
        # 듀티 변경
        p.ChangeDutyCycle(value)
        time.sleep(0.3)  # 0.3 동안 깜빡깜빡.. 바뀌는거..

        dc.reverse() # dc를 다시 역순으로!!! 밝아졌다가 어두워졌다가.. 이렇게 역순으로~
        time.sleep(0.3)

time.sleep(5)



# p.pwm 정지
p.stop()

# GPIO 개방
GPIO.cleanup()