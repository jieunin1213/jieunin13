import DHT11_2
import Adafruit_DHT
import time
import RPi.GPIO as GPIO
import time

start_btn = 6 #선풍기 on/off 버튼

fan = DHT11_2.SmartFan

GPIO.setmode(GPIO.BCM)
GPIO.setup(start_btn, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)


try:
    while True:
        if GPIO.input(start_btn) == 1:     #버튼을 눌렀을 때, 선풍기가 꺼짐....근데 이미 선풍기가 돌아갔다면, 온도 재측정까지 시간은 기다려야함 ㅠㅠ
         print("oh no...good bye..")
         fan.no_wind()
    
        elif GPIO.input(start_btn) == 0: #버튼을 안눌렀을 때, 선풍기는 자동으로 계속 실행이 된다.
            print("oh yes! smart fan start!")
            fan.wind_start()

except KeyboardInterrupt():
    pass
