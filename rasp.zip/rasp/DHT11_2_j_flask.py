# coding: utf-8
import DHT11_2_j as DHT11
# flask
from flask import Flask, render_template

# request
from flask import request

# CORS
from flask_cors import CORS

# GPIO
import RPi.GPIO as GPIO

#requests
import requests
import json

import time
import datetime 

now = datetime.datetime.now()
app = Flask(__name__)

#Cross origins 이슈 해결
CORS(app)

@app.route('/high_wind')
def high_wind():
    state = 'high_wind'
    DHT11.strength(state)

    url = 'http://192.168.0.80:8080/smarthome/DHT11/high_wind'

@app.route('/low_wind')
def low_wind():
    state = 'low_wind'
    DHT11.strength(state)

    url = 'http://192.168.0.80:8080/smarthome/DHT11/high_wind'

@app.route('/stop_wind')
def stop_wind():
    GPIO.output(A,GPIO.LOW)
    GPIO.output(B,GPIO.LOW)

    url = 'http://192.168.0.80:8080/smarthome/DHT11/stop_wind'

print(__name__)
if __name__ == '__main__':
    app.run(host='192.168.0.63', port=5000, debug=False)
