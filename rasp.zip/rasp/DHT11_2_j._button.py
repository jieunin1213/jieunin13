import DHT11_2_j as DHT11
import time
import RPi.GPIO as GPIO



