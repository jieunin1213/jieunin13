from flask import Flask
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BOARD)
LED_G = 16  # 초록색 LED

GPIO.setup(LED_G, GPIO.OUT, initial=GPIO.LOW)

# app = Flask(__name__)
# 
# @app.route('/')
# def light_on():
#     GPIO.output(LIGHT, GPIO.HIGH)
#     return '조명센서 제어 페이지 입니다:)'
# 
# @app.route('/light_on')
# def light_on():
#     GPIO.output(LIGHT, GPIO.HIGH)
#     return 'light on'
# 
# @app.route('/light_off')
# def light_off():
#     GPIO.output(LIGHT, GPIO.LOW)
#     return 'light off'
# 
# if __name__ == '__main__':
#     app.run(host='192.168.0.63', port=5000, debug=False)
# 