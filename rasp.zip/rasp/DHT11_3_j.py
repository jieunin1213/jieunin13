import Adafruit_DHT
import time
import RPi.GPIO as GPIO


GPIO.setwarnings(False)
GPIO.setmode(GPIO.BCM)

A = 17 #모터 A핀
B = 27 #모터 B핀

start_btn = 6 #선풍기 start 버튼


#A,B GPIO setup설정
GPIO.setup(A,GPIO.OUT,initial=GPIO.LOW) 
GPIO.setup(B,GPIO.OUT,initial=GPIO.LOW)
#GPIO.setup(start_btn, GPIO.IN, pull_up_down=GPIO.PUD_UP)
GPIO.setup(start_btn, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

#온습도센서
DHT_SENSOR = Adafruit_DHT.DHT11
DHT_PIN = 19


#회전의 강도
def strength(state):
    if state == 'strong_wind':
        print("very hot!! strong wind start")
        p1=GPIO.PWM(A,30)
        p2=GPIO.PWM(B,30)
        p1.start(40)
#motor strength
        time.sleep(10)

        return 'strong_wind'

    elif state == 'weak_wind':
        print("so so... weak wind start")
        p1=GPIO.PWM(A,10)
        p2=GPIO.PWM(B,10)
        p1.start(20) #motor strength
        time.sleep(10)


        return 'weak_wind'
    
    elif state == 'no_wind':
        print("no wind. because of low temperature")
        p1=GPIO.PWM(A,0.1)
        p2=GPIO.PWM(B,0.1)
       # p1.start(0.1) #motor strength
        time.sleep(10)


        return 'no_wind'


def dht11():
    #while 1:
        humidity, temperature = Adafruit_DHT.read(DHT_SENSOR, DHT_PIN)
        if humidity is not None and temperature is not None:
            print("Temp={0:0.1f}C Humidity={1:0.1f}%".format(temperature, humidity))
            
            if(temperature >= 30.0):
                strength('strong_wind')
                print("온도를 재측정합니다.")
                
            elif(temperature >= 27.0 and temperature < 30.0):
                strength('weak_wind')
                print("온도를 재측정합니다.")
                
            elif(temperature < 27.0):
                strength('no_wind')
                print("온도를 재측정합니다.")
                
        else:
            print("Sensor failure. Check again. ");
            
        time.sleep(1);

#def dht_none():
    #val = None

        
        

def dht_start():
    while 1:
        dht11()



while 1:

    if GPIO.input(start_btn) == 1:
         print("oh no....")
         GPIO.output(A,GPIO.LOW)
         GPIO.output(B,GPIO.LOW)
    
    elif GPIO.input(start_btn) == 0:
        print("oh yes!")
        dht11()
  

GPIO.cleanup()