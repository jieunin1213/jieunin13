import RPi.GPIO as GPIO
import time

GPIO.setmode(GPIO.BCM)
GPIO.setwarnings(False)
trig=13
echo=19

GPIO.setup(trig, GPIO.OUT)
GPIO.setup(echo, GPIO.IN)

try:
    while True:
        GPIO.output(trig,False)
        
    GPIO.output(trig, True)
    time.sleep(0.5)
    GPIO.output(trig, False)
    
    while GPIO.input(echo) == 0:
        p_start = time.time()
        
    while GPIO.input(echo) == 1:
        p_end = time.time()
        
    p_duration = p_end - p_start
    distance = p_duration * 17000
    distance = round(distance,2)
    
    print("distance : ", distance, "cm")
    
except KeyboardInterrupt:
    GPIO.cleanup()